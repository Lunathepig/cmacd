<?php include 'conn.php'; ?>
<?php include 'headtag.php' ?>
<?php include 'header1.php' ?>
<!DOCTYPE html>
<html>
<head>
<style>
table {
  font-family: arial, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

td, th {
  border: 1px solid #dddddd;
  text-align: left;
  padding: 8px;
}

tr:nth-child(even) {
  background-color: #dddddd;
}
</style>
</head>
<body>

<h2>ADMINS</h2>
<li>Add New</li>
<div class="pb-20">
            <table class="data-table table stripe hover nowrap">
              <thead>
                <tr>
                  <th>username</th>
                  <th>password</th>
                  <th class="datatable-nosort">Action</th>
                </tr>
              </thead>
              <tbody>
                <?php
                $sql="select * from admin";
                $query=$conn->query($sql);
                while($row=$query->fetch_array()){
                  ?>
                <tr>
                  <td><?php echo $row['username']; ?></td>
                  <td><?php echo $row['pass']; ?></td>
                  <td>
                    <button>EDIT</button>|<button><a href="delete.php"> DELETE</button>
                  </td>
                </tr> 
                <?php
                }
                ?>
              </tbody>
            </table>
          </div>
<h2>TRENDING TOPICS</h2>

<div class="pb-20">
            <table class="data-table table stripe hover nowrap">
              <thead>
                <tr>
                  <th>ID</th>
                  <th>OWNER</th>
                  <th>HOTEL</th>
                  <th>ADDRESS</th>
                  <th class="datatable-nosort">Action</th>
                </tr>
              </thead>
              <tbody>
                <?php
                $sql="select * from hotel";
                $query=$conn->query($sql);
                while($row=$query->fetch_array()){
                  ?>
                <tr>
                  <td><?php echo $row['hoteLId']; ?></td>
                  <td><?php echo $row['ownersname']; ?></td>
                  <td><?php echo $row['hotelname']; ?></td>
                  <td><?php echo $row['address']; ?></td>
                  <td>
                    <button>EDIT</button>|<button>DELETE</button>
                  </td>
                </tr> 
                <?php
                }
                ?>
              </tbody>
            </table>
          </div>
          <h2>POPULAR CATEGORY</h2>

<div class="pb-20">
            <table class="data-table table stripe hover nowrap">
              <thead>
                <tr>
                  <th>username</th>
                  <th>password</th>
                  <th class="datatable-nosort">Action</th>
                </tr>
              </thead>
              <tbody>
                <?php
                $sql="select * from terminals";
                $query=$conn->query($sql);
                while($row=$query->fetch_array()){
                  ?>
                <tr>
                  <td><?php echo $row['termId']; ?></td>
                  <td><?php echo $row['terminalname']; ?></td>
                  <td><?php echo $row['location']; ?></td>
                  <td>
                    <button>EDIT</button>|<button>DELETE</button>
                  </td>
                </tr> 
                <?php
                }
                ?>
              </tbody>
            </table>
          </div>

</body>
</html>

