<?php
	include('conn.php');

	$username = $_GET['username'];

	$sql="DELETE from admin where username='$username'";
	$conn->query($sql);

	$query=mysqli_query($conn,"select * from `admin` where username='username'");
	if ($query) {
        $_SESSION['message']="<div class='form-group has-danger row' style='padding-left: 15px;''><div class='form-control-feedback'><i class='icon-copy dw dw-cancel'></i> There's an error deleting account!</div></div>";
        header('location:setting.php');
    }
    else{
        $_SESSION['message']="<div class='form-group has-success row' style='padding-left: 15px;''><div class='form-control-feedback'><i class='icon-copy dw dw-checked'></i> Successfully deleted!</div></div>";
        header('location:setting.php');
    }
?>