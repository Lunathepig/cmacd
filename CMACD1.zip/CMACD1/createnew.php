<div class="mobile-menu-overlay"></div>
<div class="main-container">
	<div class="pd-ltr-20 xs-pd-20-10">
		<div class="min-height-200px">
			<!-- Adding Employee Form Starts -->
			<div class="pd-20 card-box mb-30">
				<form action="adding.php" method="POST" enctype="multipart/form-data">
					<div class="clearfix mb-20">
						<div class="pull-left">
							<h4 class="h2" data-color="#1B55FF"><i class="icon-copy dw dw-add-user"></i>  ADD NEW EMPLOYEE ACCOUNT</h4>
							<label class="form-group has-warning row" style="padding-left: 15px;"><i class="icon-copy fa fa-exclamation-circle" aria-hidden="true" style="padding-top: 4px;padding-right: 4px;"></i> Input valid information.</label>
							<?php
								if (isset($_SESSION['message'])){
									echo $_SESSION['message'];
								}
								unset($_SESSION['message']);
							?>
						</div>
						<div class="pull-right">
							<button class="btn btn-primary btn-lg btn-block" name="add" type="submit"  data-toggle="tooltip" data-placement="top" title="Click to add">
								A D D<i class="icon-copy dw dw-right-chevron"></i>
							</button>
						</div>
					</div>
					<hr>
						<div class="col-md-8 col-sm-12 mb-30">
							<h4 class="text-blue h4" data-color="#707373">Personal Information:</h4>
							<div class="row" style="padding-top: 15px;">
								<div class="col-md-6 col-sm-12">
									<div class="form-group" data-toggle="tooltip" data-placement="top" title="Enter first name">
										<label>UserName:</label>
										<input type="text" class="form-control" name="username" id="fname" required>
									</div>
								</div>
								<div class="col-md-6 col-sm-12">
									<div class="form-group" data-toggle="tooltip" data-placement="top" title="Enter last name">
										<label>Pass:</label>
										<input type="password" class="form-control" name="pass" id="lname" required>
									</div>
								</div>
							</div>
					</div>
				</form>
			</div>
			<!-- Adding Employee Form End -->
		</div>
	</div>		
</div>