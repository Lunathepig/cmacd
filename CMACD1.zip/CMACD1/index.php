<?php include('headtag.php'); ?>

<body class="body-wrapper">
	<?php include('header.php'); ?>	
<!--===============================
=            Hero Area            =
================================-->

<section class="hero-area bg-1 text-center overly">
	<!-- Container Start -->
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<!-- Header Contetnt -->
				<div class="content-block">
					<h1>Experience Places Near You </h1>
					<p>Join us everyday in our local communities around San Juan Proper</p>
					<div class="short-popular-category-list text-center">
						<h2>Popular Category</h2>
						<section class="client-slider-03">
	<!-- Container Start -->
	<div class="container">
		<div class="row">
			<!-- Client Slider -->
			<div class="col-md-12">
				<!-- Client Slider -->
<div class="category-slider">
    <!-- Client 01 -->
    <div class="item">
        <a href="hotel.php">
            <!-- Slider Image -->
            <i class="fa fa-bed"></i>
            <h4>Hotels</h4>
        </a>
    </div>
    <div class="item">
        <a href="#">
            <!-- Slider Image -->
            <i class="fa fa-car"></i>
            <h4>Vehicles</h4>
        </a>
    </div>
    <div class="item">
        <a href="restaurant.php">
            <!-- Slider Image -->
            <i class="fa fa-cutlery"></i>
            <h4>Restaurants</h4>
        </a>
    </div>
    <div class="item">
        <a href="#">
            <!-- Slider Image -->
            <i class="fa fa-film"></i>
            <h4>Gym</h4>
        </a>
    </div>
    <!-- Client 01 -->
    <div class="item">
        <a href="#">
            <!-- Slider Image -->
            <i class="fa fa-building"></i>
            <h4>Real Estate</h4>
        </a>
    </div>
    <div class="item">
        <a href="shopping.php">
            <!-- Slider Image -->
            <i class="fa fa-shopping-bag"></i>
            <h4>Shopping</h4>
        </a>
    </div>
    <div class="item">
        <a href="terminal.php">
            <!-- Slider Image -->
            <i class="fa fa-terminal"></i>
            <h4>Terminal</h4>
        </a>
    </div>
    <div class="item">
        <a href="#">
            <!-- Slider Image -->
            <i class="fa fa-medkit"></i>
            <h4>Health</h4>
        </a>
    </div>
    
</div>
			</div>
		</div>
	</div>
	<!-- Container End -->
</section>
					</div>
					
				</div>
				
			</div>
		</div>
	</div>
	<!-- Container End -->
</section>

<!--===================================
=            Client Slider            =
====================================-->
<?php include('body.php') ?>
<section class=" section">
	<div class="row py-4">
				<div class="col-lg-7 col-md-12 col-sm-12 ">
                    <div class="single-project">
                        <img src="images/user/banner1.jpeg" alt="" class="img-fluid">
                    </div>
                </div>
                <div class="col-lg-4 col-md-12 col-sm-12 ">
                    <div class="project-content-block">
                        <h1>Do you know who we are?</h1>
                        <h4><hr>San Juan (Cabalian) Southern Leyte..</h4>
                        <hr>>>The original name of the town, Cabalian, was what the Spaniards knew.
                        	When Legaspi visited Cabalian forty years after Magellan in 1561, they found the natives unfriendly and this discouraged the Spaniards. Legend has it that Magellan tried to anchor in the placee due to a broken mast and shouts from the natives "kabalian" (meaning broked) were taken by the Spaniards to be the name of the place. No historical basis existed however.Pigafetta's diary never mentionedd the incident.
                          <br>Excavated relics have shown that since the later part of the 13th century the town was known as Cabalian. The Jesuits in 1620 had buildings constructed and a watchtower build armed with faconetes y bantakas(Light cannons).</br>

                        <br>The change of the names from Cabalian to San Juan was made in honor of the towns patron saint. Saint John the baptist. The town has 18 barangays.</br></hr>
                    </div>
                </div>
				</div>
		</div>
	</div>
	<!-- Container End -->
</section>
<script>
// Get the modal
var modal = document.getElementById('id01');

// When the user clicks anywhere outside of the modal, close it
window.onclick = function(event) {
    if (event.target == modal) {
        modal.style.display = "none";
    }
}
</script>

<?php include('footer.php'); ?>

<?php include('javascript.php'); ?>
</body>

</html>