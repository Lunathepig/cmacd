<?php
// If upload button is clicked ...
  if (isset($_POST['add'])) {
    session_start();
    include('conn.php');


    $username=$_POST['username'];
    $pass=$_POST['pass'];


    // Get all the submitted data from the form
    $sql="INSERT INTO admin(username, pass) VALUES ('$username','$pass')";
    // Execute query
    $conn->query($sql);
      
    // Now let's move the uploaded image into the folder: image
    //if (move_uploaded_file($tempname, $folder))  {
    if {
        $_SESSION['message']="<div class='form-group has-success row' style='padding-left: 15px;''><div class='form-control-feedback'><i class='icon-copy dw dw-checked'></i> Successfully added!</div></div>";
        header('location:setting.php');
        
    }else{
        $_SESSION['message']="<div class='form-group has-danger row' style='padding-left: 15px;''><div class='form-control-feedback'><i class='icon-copy dw dw-cancel'></i> There's an error adding new account!</div></div>";
        header('location:createnew.php');
  }
  }
  $result = mysqli_query($conn, "SELECT * FROM admin");

?>