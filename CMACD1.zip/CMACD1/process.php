<?php
	if(isset($_POST['login'])){
 
		session_start();
		include('conn.php');
 
		$username=$_POST['username'];
		$password=$_POST['pass'];
		$query=mysqli_query($conn,"select * from `admin` where username='$username' && pass='$pass'");

            if (mysqli_num_rows($query) == 0){
				header('location:login.php');
        		$_SESSION['message']="Login Failed. User not Found!";
	   			}
				
			else{
				header('location:index.php');
			}
		}
?>